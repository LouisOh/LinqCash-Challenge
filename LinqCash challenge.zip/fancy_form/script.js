 // Bootstrap validator for form input script
 $(document).ready(function() {
          $('#bitcoin-form').bootstrapValidator({
          // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
      framework: 'bootstrap',
          feedbackIcons: {
              valid: 'glyphicon glyphicon-ok',
              invalid: 'glyphicon glyphicon-remove',
              validating: 'glyphicon glyphicon-refresh'
          },
          fields: {
              inputAddress: {
                  validators: {
                          stringLength: {
                          min: 5,
                          message: 'Bitcoin address must be at least 5 characters long'
                      },
                          notEmpty: {
                          message: 'Please enter your bitcoin address!'
                      }
                  }
              },
               inputAmount: {
                  validators: {
                      numeric: {
                            message: 'The value must be a number',
                            // The default separators
                            decimalSeparator: '.'
                        },
                      notEmpty: {
                          message: 'Please enter your amount to send!'
                      }
                  }
              },
              inputOTP: {
                  validators: {
                      stringLength: {
                          min: 3,
                          message: 'OTP must be at least 3 numbers long'
                      },
                      integer: {
                          message: 'The value must only be a number and no other character'
                      },
                      notEmpty: {
                          message: 'Please enter your OTP!'
                      }
                  }
              }
        
            }     
          })
      
                 .on('success.form.bv', function(e) {
                 
                 $('#bitcoin-form').data('bootstrapValidator').resetForm();
          
              // Prevent form submission
                 e.preventDefault();

              // Get the form instance
                 var $form = $(e.target);

              // Get the BootstrapValidator instance
                 var bv = $form.data('bootstrapValidator');
        
          });    
  });